﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Globalization;
using System.Text.RegularExpressions; //for importing regular expressions
using System.Diagnostics.Contracts;
using System.Runtime.CompilerServices;
namespace Learning{
    class basics
    {
        static void Main(string[] args)
        {
    
            //Using the int.parse method
            Console.WriteLine("enter The input from the user");
            Console.WriteLine(int.Parse(Console.ReadLine());

            //using the Convert.ToInt method
            Console.WriteLine("input from the user");
            Console.WriteLine(Convert.ToInt32(Console.ReadLine());

            //using int.tryParse method
            Console.WriteLine("Input from the user");
            Console.WriteLine(int.TryParse(Console.ReadLine());

            //Using Float.parse Method
            Console.WriteLine("Input from the user");
            Console.WriteLine(float.Parse(Console.ReadLine());




            //Single.Parse() Method
            Console.WriteLine("Input from the user");
            Console.WriteLine(Single.Parse(Console.ReadLine());

            // Convert.ToSingle() Method
            Console.WriteLine("Input from the user");
            Console.WriteLine(Convert.ToSingle(Console.ReadLine());

            //Bool.parse method
            Console.WriteLine();
            Console.WriteLine(bool.Parse(Console.ReadLine());


        }
    }
}

    
  

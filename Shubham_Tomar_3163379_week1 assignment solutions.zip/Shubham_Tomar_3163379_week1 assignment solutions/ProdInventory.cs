﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Learning
{
    class ProdInventory
    {
        public static void Main(string[] args) {
        //@overrides equals
        public class product : IEquatable<T> {
            int productId;
            int productPrice;
            string productIsDefective;
            int totalinventoryvalue;

            //creating the dictionary for storing product id with corresponds to their product quantity
            Dictionary<int, int> proddict = new Dictionary<int, int>();

            //Methods
            public void AddProduct()
            {
                proddict.Add("id", "quantity");
            }

            public void RemoveProduct() {
                if (proddict.ContainsKey("productname")) {
                    proddict.Remove("productname");
                }

            }
            public void UpdateProductQuantity()
            {
                if (proddict.ContainsKey("productname"))
                {
                    proddict["productname"] = "new productname";
                }
            }


            // On change of Product’s Price, Inventory total value should get updated.
            public void totalvalue(int productprice)
            {
                totalinventoryvalue += productprice;
            }


                // If a Product becomes defective, remove it from the inventory.
                if(proddict.ContainsKey("productname") == defective) {
                    Proddict.Remove("productname");
                }
    }
            }
    }

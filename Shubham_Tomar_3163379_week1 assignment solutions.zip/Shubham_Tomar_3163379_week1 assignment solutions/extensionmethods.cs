﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Learning
{
    public static class extensionmethods
    {
        //p/ublic static void Main(string[] args) { */
        //isodd
        public static bool isOdd(this int number)
        {
            return number % 2 == 0 ? false : true;
        }
        static void Main(string[] args)
        {
            var a = 5;
            var b = a.isOdd();
        }


          //iseven
        public static bool IsEven(this int number)
        {
            return number % 2 == 0 ? true : false;
        }

        static void Main(string[] args)
        {
            var a = 5;
            var b = a.IsEven();
        }

        //isprime
        public static bool isPrime(this int number)
        {
            int flag=0;
            for (int i = 2; i <= number / 2; i++) {
                if (number % i == 0) {
                    Console.WriteLine("number not prime");
                    flag = 1;
                    break;
                }
                if (flag == 0) Console.WriteLine("number is prime");
            }
            static void Main(string[] args)
            {
                int a = 16; int b = a.isPrime();
            }


            //isdivisble
            public static bool isdivisble(this int number1, int number2)
            {
                return number1/ number2 == 0 ? true : false;
            }

            public static void main(string[] args)
            {
                var a = 5;
                var b = 7;
                var c = a.isdivisble(b);
            }

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Learning
{
    class CRUDEQUIPMENT
    {
       
            public string Name { get; set; }
            public string Description { get; set; }
            public int DistanceMovedTillDate{get; set;}   //Defaults to 0 km)
        public int cost { get; set; }
        public virtual int MaintenanceCost{get; set;}         //(Defaults to 0

          enum  Typeofequipment
     {     //– Use enum to represent this value
                  mobileequipment,
                  immobileequipment
       }

            public void moveby(int distance){
            distance+= DistanceMovedTillDate;
                }

        public int mobile { get; set; }
        public int immobile { get; set; }
        
                 
            override public void MaintenanceCost() { 
               cost=wheels * distance;
           }
        
          override public void MaintenanaceCost()
        {
             cost = weight * distance;
       }

       public void showdetails(string name, string description, int distancemovedtilldate, int maintenancecost)
         {
        CRUDEQUIPMENT ob = new CRUDEQUIPMENT();
           ob.showdetails();
         }
    }
}

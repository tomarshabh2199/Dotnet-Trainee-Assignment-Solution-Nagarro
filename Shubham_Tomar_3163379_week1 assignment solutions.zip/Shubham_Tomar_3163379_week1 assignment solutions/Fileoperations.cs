﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Learning
{
    class Fileoperations
    {        public static void Main(string[] args) { 
        //Get all the files from a given directory and perform the following actions

        //      1.	Return the number of text files in the directory(*.txt).
        int fileCount = Directory.GetFiles(path, "*.txt*", SearchOption.AllDirectories).Length; // Will Retrieve count of all files in directry and sub directries
        Console.WriteLine(fileCount);


            //    2.Return the number of files per extension type.
            int fileCount = Directory.GetFiles(path, "*.*", SearchOption.TopDirectory).Length; // Will Retrieve count of all files in directry but not sub directries



        //3.	Return the top 5 largest files, along with their file size(use anonymous types).
        var files = Directory
        .EnumerateFiles(path, "*", SearchOption.TopDirectoryOnly)
        .Select(x => new FileInfo(x))
          .OrderByDescending(x => x.Length)
                .Take(5).ToList();


        //4.	Return the file with maximum length.



    }
}
}

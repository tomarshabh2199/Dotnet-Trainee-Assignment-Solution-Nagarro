﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Learning
{
    enum {
         Rubberducks,
        Mallardducks,
         Redheadducks
        }
class DuckSimulation
    {
        public static void Main(string[] args) { 
        public string fly { get; set; }
        
        public string squeak  { get; set; }

        public class Rubberducks : DuckSimulation
        {
            public virtual void Fly()
            {
                string fly = "No";
            }
            public virtual void Squeak()
            {
                string squeak = "No";
            }
        }
        public class Mallardducks : DuckSimulation
        {
            override public void Fly()
            {
                string fly = "Fast";
            }
            override public void Squeak()
            {
                string squeak = "Loud";
            }

        }
        public class Redheadducks : DuckSimulation
        {
            override public void Fly()
            {
                string fly = "Slow";
            }
            override public void Squeak()
            {
                string squeaks = "Mild";
            }

        }
                    //pass the method name in the constructor to call it
                    DuckSimulation ob1 = new Rubberducks();
                    ob1.Fly();
                    ob1.Squeak();

                     DuckSimulation ob2 = new Mallardducks();
                    ob2.Fly();
                    ob2.Squeak();

                    DuckSimulation ob3 = new Redheadducks();
                    ob3.Fly();
                    ob3.Squeak();


                    //calling the method
                    public void showDetails(string fly, string squeak)
                    {
                        this.fly = fly;
                        this.squeak = squeak;
                    }
                    Ob.showDetails()
                
}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Learning
{
    class Equalsmethods
    {
        public static void Main()
        {
           
            object v1 = null;

             
            object v2 = null;

            // using ReferenceEquals(object, 
            // object) method 
            bool status = Object.ReferenceEquals(v1, v2);

            // checking the status 
            if (status)
                Console.WriteLine("null is equal to null");
            else
                Console.WriteLine("null is not equal to null");

            //using equality operator and equals
            string str = "hello";
            string str2 = str;
            Console.WriteLine("Using Equality operator: {0}", str == str2);
            Console.WriteLine("Using equals() method: {0}", str.Equals(str2));
            Console.ReadKey();

        }
    }
}

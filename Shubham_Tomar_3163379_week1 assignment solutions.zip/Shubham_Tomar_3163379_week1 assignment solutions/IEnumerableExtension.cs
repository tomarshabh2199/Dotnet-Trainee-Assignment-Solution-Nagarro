﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Learning
{
    class IEnumerableExtension
    {
        //public static void Mian(string[] args) { 
        //CustomAll
        public static IEnumerable<T> CustomAll<T>(this IEnumerable<T> a, Func<T, T> method)
        {
            return a.Select(b => method(b));
        }
        static void Main(string[] args)
        {
            var a = new List<int>();
            a.Add(97);
            a.Add(98);
            a.Add(99);
            var c = a.CustomAll((b) => { return b * b; }).Tolist();
            Console.WriteLine(c);
            Console.ReadKey();
        }

        //CustomAny
        public static IEnumerable<T> CustomAny<T>(this IEnumerable<T> a, Func<T, T> method)
        {
            return a.Select(b => method(b));
        }
        static void Main(string[] args)
        {
            var a = new List<int>();
            a.Add(23);
            a.Add(24);
            var c = a.CustomAny((b) => { return b * b; }).ToList();
            Console.WriteLine(c);
            Console.ReadKey();
        


        //CustomMax
        public static IEnumerable<T> CustomMax<T>(this IEnumerable<T> d, Func<T, T> method)
        {
            return d.Select(b => method(e));
        }
        static void Main(string[] args)
        {
            var d = new List<int> { 10, 15, 12, 13 };
            var e = d.CustomMax((b) => { return d.Max(); }).ToList();
            Console.WriteLine(c);
            Console.ReadKey();
        }


        //customMin
        public static IEnumerable<T> CustomMin<T>(this IEnumerable<T> f, Func<T, T> method)
        {
            return f.Select(g => method(g));
        }
        static void Main(string[] args)
        {
            var f = new List<int> { 10, 15, 12, 13 };
            var g = a.CustomMin((g) => { return f.Min(); }).ToList();
            Console.WriteLine(g);
            Console.ReadKey();
        }
    }



    //CustomWhere
    public static IEnumerable<T> CustomWhere<T>(this IEnumerable<T> number, bool condition, Func<T, bool> predicate)

    {
        if (condition > 0) return number.Where(predicate);
        else return number;

        public static void main(string[] args)
        {
            List<Customer> custs = new List<Customer>{
             new Customer {FirstName = "Peggy", AcctBalance = 12442.98},
             new Customer {FirstName = "Tommy", AcctBalance = 12345}
};

            bool showAccountBalancesUnder5000 = false;

            var custList = custs.CustomWhere(showAccountBalancesUnder5000, c => c.AcctBalance < 5000).ToList();

            showAccountBalancesUnder5000 = true;

            var custListUnder5000 = custs.CustomWhere(showAccountBalancesUnder5000, c => c.AcctBalance < 5000).ToList();
        }

        

        //CustomSelect
        public static IEnumerable<T> CustomSelect<T>(this IEnumerable<T> a, Func<T, T> method)
        {
            {
                return a.Select(b => method(b));
            }
            static void Main(string[] args)
            {
                var a = new List<int> { 10, 15, 12, 13 };
                var c = a.CustomSelect((b) => { return a.Select(a => a.Length); }).ToList();
                Console.WriteLine(c);
                Console.ReadKey();
            }
        }

    }
    }
}

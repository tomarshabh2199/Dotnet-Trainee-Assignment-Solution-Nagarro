﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Learning
{
    class lambdadelegates
    {
                     //findodd
            static void Main(string[] args)
            {
                List<int> numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
                var result = numbers.Where(number => number % 2 != 0);
                Console.WriteLine(String.Join(" ", result));
                Console.WriteLine();
            }
        }
    }

                     //Find Even
	
            static void Main(string[] args)
            {
                List<int> numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
                var result = numbers.Where(number => number % 2 == 0);
                Console.WriteLine(String.Join(" ", result));
                Console.WriteLine();
            }
    
                         //find prime-

            public static void Main(string[] args)
            {
                List<int> numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
                var result = numbers.Where(number => prime(n));
                Console.WriteLine(String.Join(" ", result));
                Console.ReadLine();
                static void prime(int n)
                {
                    int n, i, m = 0, flag = 0;
                    Console.Write("Enter the Number to check Prime: ");
                    n = int.Parse(Console.ReadLine());
                    m = n / 2;
                    for (i = 2; i <= m; i++)
                    {
                        if (n % i == 0)
                        {
                            Console.Write("Number is not Prime.");
                            flag = 1;
                            break;
                        }
                    }
                    if (flag == 0)
                        Console.Write("Number is Prime.");
                }
            }
        



//Find Elements Greater Than Five
  
      
                public static void Main(string[] args)
                {
                    List<int> numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
                    var result = numbers.Where(number => number > 5);
                    Console.WriteLine(String.Join(" ", result));
                    Console.ReadLine();
                }
       

                //Find Less than Five
                public static void Main(string[] args)
                {
                    List<int> numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
                    var result = numbers.Where(number => number < 5);
                    Console.WriteLine(String.Join(" ", result));
                    Console.ReadLine();
                }
        

                //Find 3k
                public static void Main(string[] args)
                {
                    List<int> numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
                    var result = numbers.Where(number => number * 3);
                    Console.WriteLine(String.Join(" ", result));
                    Console.ReadLine();
                }



                        //Find 3k + 1 
                public static void Main(string[] args)
                {
                    List<int> numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
                    var result = numbers.where({
                        number = (number * 3)+1);
                       };
            Console.WriteLine(String.Join(" ", result));
            Console.ReadLine();
        }
   

                    //Find 3k + 2
        public static void Main(string[] args)
        {
            List<int> numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            var result = numbers.Where(number => number * 3 + 2);
        Console.WriteLine(String.Join( " ", result));
        Console.ReadLine();
    }



        delegate void findAnything(int number);
         public static void Main(string[] args)
       {
          int number;
            number = cube.3;
     }
     public int cube(int number)
     {
          return number*number * number;
        }



       delegate void findAnything(int number);
       public static void Main(string[] args)
     {
             int number;
          number = squarenumber(3);
   }
     public int squarenumber(int number)
      {
        return number*number;
       }


﻿using System;
using System.Collections
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Learning
{
    class ExtendInventory
    {
        List<string> list = new List<string>();
        list.Add("jcb");

        list.Add("ladder");

        list.Add("jeep");


         //            or
       //IList<Equipment>list= new List<>();

        public void CreateEquipment(string equipmentname)
        {
            list.Add(equipmentname);
        }


        public void DeleteEquipment(string equipmentname)
        {
            list.Remove(equipmentname);
        }


        public void updateEquipment(String equipmentname)
        {
            if(list.Contains("mobile equipment"){
                list.Add("immobile equipment");
            }
            else {
                list.Add("mobileequipment");
            }



            list.ForEach(e => Console.WriteLine(e));


            //showing all details of equipment
            foreach(var item in list){ //iterating the list
                {
                    Console.WriteLine("equipment name:{ 0} ” equipmentname, + ”equipment description:{ 1}” equipment description + ”equipment maintenance :{ 2}” maintenance cost + ”equipment distance till: { 3} ” distance);
                }


                list.foreach (equipmentname => from equipment in equipment where equipment in mobile);


                list.foreach (equipmentname =>  from equipment in equipment where equipment in immobile);


                list.RemoveAll();


                list.RemoveAll(x =>  from equipment in equipment where equipment in immobile);


                list.RemoveAll(x =>   from equipment in equipment where equipment in mobile);

            }
        }

    }
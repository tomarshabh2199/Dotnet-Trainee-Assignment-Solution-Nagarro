﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Learning
{
    class ObservableCollection
    {
        public enum NotifyCollectionChangedAction
        {
            Add,
            Remove
        }
        public class NotifyCollectionChangedEventArgs : EventArgs
        {
            public NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction action)
            {
                if (action != NotifyCollectionChangedAction.Reset)
                    throw new ArgumentException(SR.GetString(SR.WrongActionForCtor, NotifyCollectionChangedAction.Reset), "action");
                InitializeAdd(action, null, -1);
            }
            public NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction action, object changedItem)
            {
                if ((action != NotifyCollectionChangedAction.Add) && (action != NotifyCollectionChangedAction.Remove)
                        && (action != NotifyCollectionChangedAction.Reset))
                    throw new ArgumentException(SR.GetString(SR.MustBeResetAddOrRemoveActionForCtor), "action");
                if (action == NotifyCollectionChangedAction.Reset)
                {
                    if (changedItem != null)
                        throw new ArgumentException(SR.GetString(SR.ResetActionRequiresNullItem), "action");

                    InitializeAdd(action, null, -1);
                }
                else
                {
                    InitializeAddOrRemove(action, new object[] { changedItem }, -1);
                }
            }
            public NotifyCollectionChangedAction Action
            {
                get { return _action; }
            }
            private NotifyCollectionChangedAction _action;
            private IL _newItems, _oldItems;
            private int _newStartingIndex = -1;
            private int _oldStartingIndex = -1;
        }

        public delegate void NotifyCollectionChangedEventHandler(object sender, NotifyCollectionChangedEventArgs e);
    }

}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Learning
{
    class MathematicsException
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("enter any number from 1 to 5");

            int num = Console.ReadLine();
            switch (num)
            {
                case 1:
                    Console.WriteLine("Enter even number");
                    Console.WriteLine("Suceess");
                    break;
                case 2:
                    Console.WriteLine("Enter odd number");
                    Console.WriteLine("Suceess");
                    break;
                case 3:
                    Console.WriteLine("Enter prime number");
                    Console.WriteLine("Suceess");
                    break;
                case 4:
                    Console.WriteLine("Enter negative number");
                    Console.WriteLine("Suceess");
                    break;
                case 5:
                    Console.WriteLine("Enter zero ");
                    Console.WriteLine("Suceess");
                    break;
                default:
                    Console.WriteLine("Error mesage");
                    goto 1;
            }
        class CustomException : Exception
        {
               try{
                 //validate the input parameters
                 //even number validation
              
        if(num%2==0) Console.WriteLine("this is even number");

        if(num%2!=0) Console.WriteLine("this is odd number");

        if(num<1) Console.WriteLine("this is negative number");

        if(num==0) Console.WriteLine("this is zero");

           if(num==prime(num)
           Console.WriteLine(" this is prime number");
    }
         catch(Exception e)
    {
        Console.WriteLine("You have played the game upto 5 Times");
    }
}
}

 

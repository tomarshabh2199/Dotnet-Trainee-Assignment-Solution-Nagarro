﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Learning
{
    class ExtendDuck
    {
        public static void Main(string[] args) { 
        List<string> duck = new List<string>();


        duck.Add("duckname");

        duck.Remove("duckname");
 
     //remove all duck
        duck.Clear(); 
            //or
       // duck.empty();

        //ICollection<int, int> c = new ICollection<int, int>();
            SortedList<int,int> sl = new SortedList<int,int>();
            //it contains the weight and wings of the duck


            //ICollections.sort(weights);
            sl.Add("name", "weights");

          foreach(var items in sl)
            {
         Console.WriteLine(items);
          Console.ReadLine();

            }


            sl.Add("name", "wings);

            foreach (var items in sl)
        {
         Console.WriteLine(items);
         Console.ReadKey();
        }


    }
}
}